# Tastelume — Diagrama escrito da aplicação

## 1. Arquitetura em árvore

```text
TASTELUME
│
├── A. APLICAÇÃO MÓVEL — Flutter / Dart
│   ├── Views (ecrãs e componentes visuais)
│   ├── ViewModels (estado e lógica de apresentação — MVVM)
│   ├── Models (modelos usados pela app)
│   ├── Repositories (encapsulam chamadas à API)
│   ├── Cliente HTTP (REST/JSON)
│   ├── Câmara e galeria (captura/seleção de fotografias)
│   └── Armazenamento seguro do token JWT
│
└── B. BACKEND — Docker Compose
    │
    ├── 1. Users Service — FastAPI
    │   ├── Registo, login e JWT
    │   ├── Perfis, pesquisa de utilizadores e interesses
    │   ├── Seguidores e pessoas seguidas
    │   └── PostgreSQL próprio: Users DB
    │
    ├── 2. Recipe Service — FastAPI
    │   ├── Criar, consultar, editar e apagar receitas
    │   ├── Pesquisa, categorias, filtros e ordenação
    │   ├── Upload e disponibilização de imagens
    │   ├── Volume persistente próprio para fotografias
    │   └── PostgreSQL próprio: Recipes DB
    │
    ├── 3. Interaction Service — FastAPI
    │   ├── Comentários, likes e avaliações de 1–5 estrelas
    │   ├── Listas personalizadas de favoritos
    │   ├── Partilhas entre utilizadores
    │   ├── Mensagens diretas
    │   └── PostgreSQL próprio: Interactions DB
    │
    └── 4. Activity Service — FastAPI
        ├── Eventos de atividade e visualizações
        ├── Notificações dentro da aplicação
        ├── Estatísticas e dashboard
        └── PostgreSQL próprio: Activity DB

Cada serviço = código próprio + API REST + modelo de dados + contentor Docker + base de dados própria.
```

## 2. Ligações entre componentes

```text
Utilizador / visitante
         │
         ▼
Aplicação Flutter (MVVM)
         │
         ├── REST/JSON ──> Users Service ──> Users DB
         ├── REST/JSON ──> Recipe Service ──> Recipes DB
         │                                  └──> Volume de fotografias
         ├── REST/JSON ──> Interaction Service ──> Interactions DB
         └── REST/JSON ──> Activity Service ──> Activity DB

Integração servidor-servidor (sempre por APIs REST):
  • Interaction Service → Recipe Service: validar a receita e obter o autor.
  • Interaction Service → Activity Service: comunicar comentários, likes,
    avaliações e partilhas para notificações/estatísticas.
  • Recipe Service → Activity Service: comunicar publicação e visualizações.
  • Users Service → Activity Service: comunicar novos seguidores.
  • Activity Service → Users Service: obter seguidores para notificar sobre
    novas receitas, quando essa funcionalidade estiver implementada.
  • Recipe Service pode consultar Interaction/Activity para métricas usadas
    na ordenação; se um serviço de métricas falhar, deve usar ordenação de
    recurso (por exemplo, data) em vez de bloquear o feed.
```

## 3. Responsabilidade dos dados

| Dados | Serviço responsável |
|---|---|
| Username, email, password hash, descrição, interesses, seguidores | Users Service |
| Receitas, ingredientes, passos, categorias, metadados e caminhos das imagens | Recipe Service |
| Comentários, likes, avaliações, favoritos, partilhas e mensagens | Interaction Service |
| Eventos, visualizações, notificações e agregações estatísticas | Activity Service |
| Ficheiros das fotografias | Volume persistente gerido pelo Recipe Service |

Nenhum serviço lê diretamente a base de dados de outro serviço.

## 4. Percurso principal a demonstrar

1. O visitante abre a app e pesquisa receitas e perfis públicos.
2. O visitante regista-se ou inicia sessão; o Users Service valida as credenciais e emite o JWT.
3. O utilizador cria uma receita e captura uma fotografia com a câmara.
4. A app envia os dados e a fotografia ao Recipe Service; a receita e o ficheiro são persistidos.
5. Outro utilizador pesquisa e abre a receita; o Recipe Service devolve os dados e regista/encaminha o evento de visualização.
6. O segundo utilizador comenta, gosta e avalia através do Interaction Service.
7. As interações relevantes são comunicadas ao Activity Service para notificações e estatísticas.
8. O autor consulta o dashboard, que obtém as métricas registadas no Activity Service e as informações de interação necessárias.
9. O utilizador guarda receitas em listas próprias, segue outros utilizadores, partilha receitas e envia mensagens.

## 5. Ordem recomendada para implementação

```text
1. Instalação e configuração: Flutter, Docker, Compose, variáveis .env
   ↓
2. Serviços + bases de dados + migrações + /health + /docs
   ↓
3. Primeiro percurso end-to-end: registo/login → publicar foto/receita → feed → pesquisa
   ↓
4. Comentários, likes, classificações, favoritos e seguidores
   ↓
5. Partilhas e mensagens
   ↓
6. Eventos, notificações, visualizações, estatísticas e dashboard
   ↓
7. Testes, permissões, falhas de serviços, persistência e documentação
   ↓
8. Relatório, repositório e vídeo de demonstração
```

**Regra de trabalho:** só avançar para a fase seguinte quando a fase atual arrancar e tiver testes básicos aprovados.

## 6. Verificações essenciais

- `docker compose config` valida a configuração do Compose.
- `docker compose up --build -d` inicia os serviços.
- `docker compose ps` confirma o estado dos contentores.
- Abrir `/docs` e `/health` de cada serviço para testar as APIs.
- `flutter pub get`, `flutter analyze` e `flutter test` na pasta da aplicação.
- No emulador Android, usar `10.0.2.2` para aceder a serviços expostos no PC, em vez de `localhost`.
- Reiniciar contentores e confirmar que bases de dados e fotografias persistem.
- Parar temporariamente o Activity Service e confirmar que o feed continua disponível.
